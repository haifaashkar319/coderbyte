import pandas as pd

def probability_to_beat_boss(suit, animal, fruit, data_file="prediction.csv"):
    """
    Calculates the probability of beating the boss based on player characteristics.

    Args:
        suit (str): Card suit (e.g., 'Diamonds', 'Hearts', etc.).
        animal (str): Animal companion (e.g., 'Lion', 'Fox', etc.).
        fruit (str): Magic fruit (e.g., 'Apple', 'Bananas', etc.).
        data_file (str, optional): Path to the CSV file containing data. Defaults to "prediction.csv".

    Returns:
        float: Probability of beating the boss (rounded to two decimal places).

    Raises:
        FileNotFoundError: If the specified data file is not found.
    """

    try:
        data = pd.read_csv(data_file)
    except FileNotFoundError:
        raise FileNotFoundError(f"CSV file '{data_file}' not found.")

    filtered_data = data[(data['Card Suit'] == suit) &
                         (data['Animal Name'] == animal) &
                         (data['Fruit'] == fruit)]

    if len(filtered_data) == 0:
        print("No data found for the given combination.")
        return 0

    total_players = len(filtered_data)
    players_beat_boss = len(filtered_data[filtered_data['Result'] == True])

    probability = (players_beat_boss / total_players) * 100
    return probability
if __name__ == "__main__":
    # Example usage
    suit = "Hearts"
    animal = "Lion"
    fruit = "Apple"

    # You can replace the data_file argument here if needed
    try:
        probability = probability_to_beat_boss(suit, animal, fruit)
        print(f"Probability of beating the boss: {probability:.2f}%")
    except FileNotFoundError as e:
        print(e)
